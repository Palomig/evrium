// Содержимое всех разделов
const content = {
    'intro': `
        <div class="section">
            <h2>Добро пожаловать в гайд по геометрии!</h2>
            <p>Этот интерактивный гайд основан на учебнике геометрии Атанасяна Л.С. для 7-9 классов. Здесь вы найдёте:</p>
            <ul>
                <li>Краткие и понятные объяснения всех важных тем</li>
                <li>Наглядные иллюстрации геометрических фигур и теорем</li>
                <li>Основные формулы и доказательства</li>
                <li>Практические задания для отработки материала</li>
            </ul>
            <p style="margin-top: 20px;"><strong>Выберите тему в меню слева, чтобы начать изучение!</strong></p>
        </div>
    `,
    
    'triangles-basic': `
        <div class="section">
            <h2>Треугольники: Основные понятия</h2>
            
            <p>Треугольник — это геометрическая фигура, образованная тремя отрезками, которые соединяют три точки, не лежащие на одной прямой.</p>

            <svg width="400" height="300" viewBox="0 0 400 300">
                <polygon points="200,50 100,250 300,250" fill="none" stroke="#667eea" stroke-width="3"/>
                <circle cx="200" cy="50" r="5" fill="#764ba2"/>
                <circle cx="100" cy="250" r="5" fill="#764ba2"/>
                <circle cx="300" cy="250" r="5" fill="#764ba2"/>
                <text x="200" y="35" text-anchor="middle" font-size="18" fill="#764ba2" font-weight="bold">A</text>
                <text x="85" y="265" text-anchor="middle" font-size="18" fill="#764ba2" font-weight="bold">B</text>
                <text x="315" y="265" text-anchor="middle" font-size="18" fill="#764ba2" font-weight="bold">C</text>
                <text x="150" y="155" text-anchor="middle" font-size="16" fill="#ff5722">c</text>
                <text x="250" y="155" text-anchor="middle" font-size="16" fill="#ff5722">b</text>
                <text x="200" y="270" text-anchor="middle" font-size="16" fill="#ff5722">a</text>
            </svg>

            <h3>Элементы треугольника</h3>
            <ul>
                <li><strong>Вершины:</strong> точки A, B, C</li>
                <li><strong>Стороны:</strong> отрезки AB, BC, AC</li>
                <li><strong>Углы:</strong> ∠A, ∠B, ∠C</li>
            </ul>

            <div class="theorem">
                <strong>Теорема о сумме углов треугольника:</strong><br>
                Сумма углов любого треугольника равна 180°
            </div>

            <div class="formula">
                $$\\angle A + \\angle B + \\angle C = 180°$$
            </div>

            <div class="example">
                <strong>💡 Пример:</strong><br>
                В треугольнике ABC известны два угла: ∠A = 70° и ∠B = 50°. Найдём ∠C:<br>
                $$\\angle C = 180° - \\angle A - \\angle B = 180° - 70° - 50° = 60°$$
            </div>

            <h3>Виды треугольников по углам</h3>
            
            <svg width="700" height="250" viewBox="0 0 700 250">
                <polygon points="80,50 30,200 130,200" fill="none" stroke="#667eea" stroke-width="2"/>
                <text x="80" y="230" text-anchor="middle" font-size="14">Остроугольный</text>
                
                <polygon points="280,50 230,200 330,200" fill="none" stroke="#667eea" stroke-width="2"/>
                <line x1="280" y1="200" x2="280" y2="185" stroke="#ff5722" stroke-width="2"/>
                <line x1="280" y1="200" x2="295" y2="200" stroke="#ff5722" stroke-width="2"/>
                <text x="280" y="230" text-anchor="middle" font-size="14">Прямоугольный</text>
                
                <polygon points="480,80 430,200 550,200" fill="none" stroke="#667eea" stroke-width="2"/>
                <text x="490" y="230" text-anchor="middle" font-size="14">Тупоугольный</text>
            </svg>

            <ul>
                <li><strong>Остроугольный:</strong> все углы острые (меньше 90°)</li>
                <li><strong>Прямоугольный:</strong> один угол равен 90°</li>
                <li><strong>Тупоугольный:</strong> один угол тупой (больше 90°)</li>
            </ul>

            <h3>Виды треугольников по сторонам</h3>
            
            <svg width="700" height="250" viewBox="0 0 700 250">
                <polygon points="80,50 30,200 130,200" fill="none" stroke="#667eea" stroke-width="2"/>
                <text x="80" y="230" text-anchor="middle" font-size="14">Разносторонний</text>
                
                <polygon points="280,50 240,200 320,200" fill="none" stroke="#667eea" stroke-width="2"/>
                <line x1="240" y1="200" x2="260" y2="200" stroke="#ff5722" stroke-width="3"/>
                <line x1="300" y1="200" x2="320" y2="200" stroke="#ff5722" stroke-width="3"/>
                <text x="280" y="230" text-anchor="middle" font-size="14">Равнобедренный</text>
                
                <polygon points="490,50 440,200 540,200" fill="none" stroke="#667eea" stroke-width="2"/>
                <text x="490" y="230" text-anchor="middle" font-size="14">Равносторонний</text>
            </svg>

            <ul>
                <li><strong>Разносторонний:</strong> все стороны разной длины</li>
                <li><strong>Равнобедренный:</strong> две стороны равны (боковые стороны), третья — основание</li>
                <li><strong>Равносторонний:</strong> все три стороны равны, все углы по 60°</li>
            </ul>

            <div class="example">
                <strong>💡 Свойство равнобедренного треугольника:</strong><br>
                В равнобедренном треугольнике углы при основании равны.<br>
                Например, если AB = AC, то ∠B = ∠C.
            </div>

            <h3>Неравенство треугольника</h3>

            <div class="theorem">
                <strong>Неравенство треугольника:</strong><br>
                Каждая сторона треугольника меньше суммы двух других сторон.
            </div>

            <div class="formula">
                $$a < b + c,\\quad b < a + c,\\quad c < a + b$$
            </div>

            <div class="example">
                <strong>💡 Практическое применение:</strong><br>
                Можно ли построить треугольник со сторонами 3, 4 и 10?<br>
                Проверим: $3 + 4 = 7 < 10$ — неравенство не выполнено!<br>
                <strong>Ответ:</strong> Нельзя, такой треугольник не существует.
            </div>
        </div>
    `,

    'triangles-equal': `
        <div class="section">
            <h2>Признаки равенства треугольников</h2>
            
            <p>Два треугольника называются равными, если их можно совместить наложением.</p>

            <div class="theorem">
                <strong>Первый признак (СУС - сторона, угол, сторона):</strong><br>
                Если две стороны и угол между ними одного треугольника равны соответственно двум сторонам и углу между ними другого треугольника, то такие треугольники равны.
            </div>

            <svg width="600" height="250" viewBox="0 0 600 250">
                <polygon points="100,50 50,200 180,200" fill="none" stroke="#667eea" stroke-width="3"/>
                <text x="100" y="40" text-anchor="middle" font-size="16" font-weight="bold">A</text>
                <text x="40" y="215" text-anchor="middle" font-size="16" font-weight="bold">B</text>
                <text x="190" y="215" text-anchor="middle" font-size="16" font-weight="bold">C</text>
                <text x="75" y="130" text-anchor="middle" font-size="14" fill="#ff5722">a</text>
                <text x="145" y="130" text-anchor="middle" font-size="14" fill="#ff5722">b</text>
                
                <text x="300" y="125" text-anchor="middle" font-size="24">=</text>
                
                <polygon points="450,50 400,200 530,200" fill="none" stroke="#764ba2" stroke-width="3"/>
                <text x="450" y="40" text-anchor="middle" font-size="16" font-weight="bold">A₁</text>
                <text x="390" y="215" text-anchor="middle" font-size="16" font-weight="bold">B₁</text>
                <text x="540" y="215" text-anchor="middle" font-size="16" font-weight="bold">C₁</text>
                <text x="425" y="130" text-anchor="middle" font-size="14" fill="#ff5722">a</text>
                <text x="495" y="130" text-anchor="middle" font-size="14" fill="#ff5722">b</text>
            </svg>

            <div class="formula">
                AB = A₁B₁, AC = A₁C₁, ∠A = ∠A₁ ⇒ ΔABC = ΔA₁B₁C₁
            </div>

            <div class="theorem">
                <strong>Второй признак (УСУ - угол, сторона, угол):</strong><br>
                Если сторона и два прилежащих к ней угла одного треугольника равны соответственно стороне и двум прилежащим к ней углам другого треугольника, то такие треугольники равны.
            </div>

            <div class="formula">
                AB = A₁B₁, ∠A = ∠A₁, ∠B = ∠B₁ ⇒ ΔABC = ΔA₁B₁C₁
            </div>

            <div class="theorem">
                <strong>Третий признак (ССС - сторона, сторона, сторона):</strong><br>
                Если три стороны одного треугольника равны соответственно трём сторонам другого треугольника, то такие треугольники равны.
            </div>

            <div class="formula">
                AB = A₁B₁, BC = B₁C₁, AC = A₁C₁ ⇒ ΔABC = ΔA₁B₁C₁
            </div>

            <div class="important">
                <strong>Важно:</strong> Из равенства треугольников следует равенство всех соответствующих элементов (сторон, углов, высот, медиан и т.д.)
            </div>
        </div>
    `,

    'triangles-similar': `
        <div class="section">
            <h2>Признаки подобия треугольников</h2>
            
            <p>Два треугольника называются подобными, если их углы соответственно равны и стороны одного пропорциональны сторонам другого.</p>

            <svg width="600" height="300" viewBox="0 0 600 300">
                <polygon points="150,50 50,250 250,250" fill="none" stroke="#667eea" stroke-width="3"/>
                <text x="150" y="40" text-anchor="middle" font-size="16">A</text>
                <text x="40" y="265" text-anchor="middle" font-size="16">B</text>
                <text x="260" y="265" text-anchor="middle" font-size="16">C</text>
                
                <text x="300" y="150" text-anchor="middle" font-size="24">∼</text>
                
                <polygon points="480,100 420,250 540,250" fill="none" stroke="#764ba2" stroke-width="3"/>
                <text x="480" y="90" text-anchor="middle" font-size="16">A₁</text>
                <text x="410" y="265" text-anchor="middle" font-size="16">B₁</text>
                <text x="550" y="265" text-anchor="middle" font-size="16">C₁</text>
            </svg>

            <div class="theorem">
                <strong>Первый признак (по двум углам):</strong><br>
                Если два угла одного треугольника равны двум углам другого треугольника, то такие треугольники подобны.
            </div>

            <div class="formula">
                ∠A = ∠A₁, ∠B = ∠B₁ ⇒ ΔABC ∼ ΔA₁B₁C₁
            </div>

            <div class="theorem">
                <strong>Второй признак (по двум сторонам и углу между ними):</strong><br>
                Если две стороны одного треугольника пропорциональны двум сторонам другого треугольника и углы между этими сторонами равны, то такие треугольники подобны.
            </div>

            <div class="formula">
                AB/A₁B₁ = AC/A₁C₁, ∠A = ∠A₁ ⇒ ΔABC ∼ ΔA₁B₁C₁
            </div>

            <div class="theorem">
                <strong>Третий признак (по трём сторонам):</strong><br>
                Если три стороны одного треугольника пропорциональны трём сторонам другого треугольника, то такие треугольники подобны.
            </div>

            <div class="formula">
                AB/A₁B₁ = BC/B₁C₁ = AC/A₁C₁ ⇒ ΔABC ∼ ΔA₁B₁C₁
            </div>

            <h3>Коэффициент подобия</h3>
            <p>Отношение соответствующих сторон подобных треугольников называется коэффициентом подобия (k).</p>

            <div class="formula">
                k = AB/A₁B₁ = BC/B₁C₁ = AC/A₁C₁
            </div>

            <div class="important">
                <strong>Свойства подобных треугольников:</strong>
                <ul>
                    <li>Отношение периметров равно коэффициенту подобия</li>
                    <li>Отношение площадей равно квадрату коэффициента подобия</li>
                </ul>
            </div>
        </div>
    `,

    'triangles-pythagorean': `
        <div class="section">
            <h2>Теорема Пифагора</h2>
            
            <div class="theorem">
                <strong>Теорема Пифагора:</strong><br>
                В прямоугольном треугольнике квадрат гипотенузы равен сумме квадратов катетов.
            </div>

            <svg width="500" height="400" viewBox="0 0 500 400">
                <polygon points="150,80 150,330 400,330" fill="none" stroke="#667eea" stroke-width="4"/>
                <line x1="150" y1="330" x2="150" y2="315" stroke="#ff5722" stroke-width="3"/>
                <line x1="150" y1="330" x2="165" y2="330" stroke="#ff5722" stroke-width="3"/>
                
                <text x="140" y="210" text-anchor="end" font-size="20" fill="#ff5722" font-weight="bold">a</text>
                <text x="275" y="355" text-anchor="middle" font-size="20" fill="#ff5722" font-weight="bold">b</text>
                <text x="285" y="195" text-anchor="middle" font-size="20" fill="#764ba2" font-weight="bold">c</text>
                
                <text x="150" y="65" text-anchor="middle" font-size="18" font-weight="bold">A</text>
                <text x="135" y="345" text-anchor="end" font-size="18" font-weight="bold">B</text>
                <text x="415" y="345" text-anchor="start" font-size="18" font-weight="bold">C</text>
            </svg>

            <div class="formula">
                c² = a² + b²
            </div>

            <p>где c — гипотенуза (сторона, противолежащая прямому углу), a и b — катеты.</p>

            <div class="proof">
                <strong>Доказательство (одно из множества):</strong><br>
                Строим квадрат со стороной (a+b). Внутри размещаем 4 одинаковых прямоугольных треугольника так, что в центре образуется квадрат со стороной c.
                <br><br>
                Площадь большого квадрата: (a+b)²<br>
                Площадь 4 треугольников: 4·(ab/2) = 2ab<br>
                Площадь внутреннего квадрата: c²<br>
                <br>
                (a+b)² = 2ab + c²<br>
                a² + 2ab + b² = 2ab + c²<br>
                a² + b² = c²
            </div>

            <div class="theorem">
                <strong>Обратная теорема Пифагора:</strong><br>
                Если квадрат одной стороны треугольника равен сумме квадратов двух других сторон, то треугольник прямоугольный.
            </div>

            <h3>Пифагоровы тройки</h3>
            <p>Это наборы трёх натуральных чисел, удовлетворяющих теореме Пифагора:</p>
            <ul>
                <li>3, 4, 5 (3² + 4² = 9 + 16 = 25 = 5²)</li>
                <li>5, 12, 13</li>
                <li>8, 15, 17</li>
                <li>7, 24, 25</li>
            </ul>
        </div>
    `
};

// Функция переключения подменю
function toggleSubmenu(element) {
    const submenu = element.nextElementSibling;
    const arrow = element.querySelector('.arrow');
    
    if (submenu && submenu.classList.contains('submenu')) {
        submenu.classList.toggle('open');
        if (arrow) {
            arrow.classList.toggle('open');
        }
    } else {
        // Если нет подменю, показываем раздел
        const section = element.getAttribute('data-section');
        if (section) {
            showSection(section);
        }
    }
}

// Функция отображения раздела
function showSection(sectionId) {
    const contentDiv = document.getElementById('main-content');
    
    if (content[sectionId]) {
        contentDiv.innerHTML = content[sectionId];
        
        // Убираем активный класс со всех пунктов меню
        document.querySelectorAll('.menu-parent, .menu-child').forEach(item => {
            item.classList.remove('active');
        });
        
        // Добавляем активный класс к текущему пункту
        const activeItem = document.querySelector(`[onclick="showSection('${sectionId}')"]`);
        if (activeItem) {
            activeItem.classList.add('active');
        }
        
        // Прокручиваем контент наверх
        contentDiv.scrollTop = 0;
    }
}

// Функция для переключения ответа
function toggleAnswer(button) {
    const answer = button.previousElementSibling;
    answer.classList.toggle('show');
    button.textContent = answer.classList.contains('show') ? 'Скрыть ответ' : 'Показать ответ';
}

// Загружаем введение при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    showSection('intro');
});
